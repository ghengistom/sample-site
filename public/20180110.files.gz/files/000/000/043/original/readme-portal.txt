To use this example you must do the following:

1)  Add the following Portal .DLLs as references in your .NET project or your projects bin folder:

C:\Program Files\activePDF\Portal\WebControl\APPortal.dll
C:\Program Files\activePDF\Portal\WebControl\APPortalUI.dll


2)  If not using the default portal setup you may need to adjust the web.config that is included in this example.  If you are using an existing project you will need to update the web.config for your project to include the Portal HTTP Handler and App Settings.

For more information please refer to the activePDF Portal Documentation (Installation & Setup -> ASP.NET Setup).

